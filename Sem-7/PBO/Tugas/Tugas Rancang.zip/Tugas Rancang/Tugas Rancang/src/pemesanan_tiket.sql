CREATE TABLE tiket (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100),
    transportasi VARCHAR(50),
    tanggal DATE,
    harga DOUBLE
);
