package com.example.tts_672022302

data class Pertanyaan(
    val questionText: String,
    val options: List<String>,
    val correctAnswer: String
)